
//Turn.h contains Linked_List.h that contains Struct_Definitions.h, that has all libraries used
//#include <stdio.h>
//#include <string.h>
//#include <stdbool.h>
//#include <stdlib.h>
//#include <ctype.h>
//
//and the definitions of the structs
//Is only necessary to define once this file, otherwise, this will return errors
#include "Turn.h"
#include "SetBoard.h"


//--------------------------------
// MAIN FUNCTION
//--------------------------------
int main() {
    //declare the two players
    Player P1, P2;


    //Display header
    header();
    printf("Press enter to start the game\n");
    system("pause");

    //Clean console
    system("cls");//IN LINUX CHANGE TO system("clean");

    //Set number of turns (since there are no wining condition so far)
    int turns, i;
    printf("\nSelect the number of turns to play: ");
    scanf("%d", &turns);

    //Set the values of the intial board
    Initial_Board(&P1, &P2);
    //display header
    header();
    //print board
    Print_Board();

    i = 0;
    //This is just for play 2 turns
    while (i < turns) {
        //display the turn number
        printf("Turn %d \n", i + 1);

        //Turn of player 1
        Turn(&P1);//call turn
        Print_Board();//print board

        printf("Press enter to continue...\n");
        getchar();
        getchar();

        system("cls");//IN LINUX CHANGE TO system("clean");
        header();//display header
        Print_Board();//print board
        printf("Turn %d \n", i + 1);

        //Turn of player 2
        Turn(&P2);
        Print_Board();//print board

        printf("Press enter to continue...\n");
        getchar();
        getchar();
        system("cls");//IN LINUX CHANGE TO system("clean");
        header();//display header
        Print_Board();//print board
        i++;
    }


    return 0;
}

