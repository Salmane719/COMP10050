//
// Created by Draum on 07/04/2020.
//

#ifndef DOMINATION_SETBOARD_H
#define DOMINATION_SETBOARD_H
#include "Linked_List.h"
//**Function to initialize the game**//
void header();
void Print_Board();
void Initial_Board(Player *P1, Player *P2);
#endif //DOMINATION_SETBOARD_H
